package com.moviles.comic_practico1.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.moviles.comic_practico1.R
import com.moviles.models.Comics

class ComicRecyclerAdapter(val data: ArrayList<Comics>, val lisener: OnComicListener) :
    RecyclerView.Adapter<ComicRecyclerAdapter.ComicViewHolder>() {
    class ComicViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val lblName: TextView
        val btnShow: Button

        init {
            lblName = itemView.findViewById(R.id.lblName)
            btnShow = itemView.findViewById(R.id.btnShow)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ComicViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.comic_item_layout, parent, false)
        return ComicViewHolder(view)
    }

    override fun onBindViewHolder(holder: ComicViewHolder, position: Int) {
        val comic = data[position]
        holder.lblName.text = comic.nombre
        holder.btnShow.setOnClickListener {
            lisener.onShowClick(comic)
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }

    interface OnComicListener {
        fun onShowClick(comic: Comics)
    }
}