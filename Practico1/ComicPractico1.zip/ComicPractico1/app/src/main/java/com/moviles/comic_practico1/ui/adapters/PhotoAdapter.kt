package com.moviles.comic_practico1.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.moviles.comic_practico1.R

class PhotoAdapter(val data: ArrayList<Int>) :
    RecyclerView.Adapter<PhotoAdapter.ComicViewHolder>() {

    class ComicViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgComic: ImageView

        init {
            imgComic = itemView.findViewById(R.id.imgComic)
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ComicViewHolder, position: Int) {
        var img = data[position]
        holder.itemView.setBackgroundResource(img)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ComicViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.photo_layout, parent, false)
        return ComicViewHolder(view)
    }


}

