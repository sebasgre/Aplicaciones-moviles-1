package com.moviles.comic_practico1.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.moviles.comic_practico1.R
import com.moviles.comic_practico1.ui.adapters.ComicRecyclerAdapter
import com.moviles.models.Comics

class MainActivity : AppCompatActivity(), ComicRecyclerAdapter.OnComicListener {
    private lateinit var lstList: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        lstList = findViewById(R.id.lstComics)
        setupListView()
    }

    private fun setupListView() {
        var batmanfotos = arrayListOf<Int>(
            R.drawable.imagen1,
            R.drawable.imagen2,
            R.drawable.imagen3,
            R.drawable.imagen4,
            R.drawable.imagen5,
            R.drawable.imagen6,
            R.drawable.imagen7,
            R.drawable.imagen8,
            R.drawable.imagen9,
            R.drawable.imagen10
        )
        var supermanFotos = arrayListOf<Int>(
            R.drawable.imagen11,
            R.drawable.imagen12,
            R.drawable.imagen13,
            R.drawable.imagen14,
            R.drawable.imagen15,
            R.drawable.imagen16,
            R.drawable.imagen17,
            R.drawable.imagen18,
            R.drawable.imagen19,
            R.drawable.imagen20
        )
        var spidermanFotos = arrayListOf<Int>(
            R.drawable.imagen21,
            R.drawable.imagen22,
            R.drawable.imagen23,
            R.drawable.imagen24,
            R.drawable.imagen25,
            R.drawable.imagen26,
            R.drawable.imagen27,
            R.drawable.imagen28,
            R.drawable.imagen29,
            R.drawable.imagen30
        )
        val comics = arrayListOf<Comics>(
            Comics(
                1,
                "Batman",
                batmanfotos
            ),
            Comics(
                2,
                "Superman",
                supermanFotos
            ),
            Comics(
                3,
                "Spiderman",
                spidermanFotos
            )
            )
        val adapter = ComicRecyclerAdapter(comics, this)
        lstList.layoutManager = LinearLayoutManager(
            this,
            LinearLayoutManager.VERTICAL,
            false
        )
        lstList.adapter = adapter
    }

    override fun onShowClick(comic: Comics) {
        var intend = Intent(this, InfoComic::class.java)
        intend.putExtra("comics", comic)
        startActivity(intend)
    }
}