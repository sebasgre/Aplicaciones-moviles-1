package com.moviles.models

import java.io.Serializable

data class Comics(
    var id: Int,
    var nombre: String,
    var fotos: ArrayList<Int>
) : Serializable{

}