package com.moviles.practicaapi.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.moviles.practicaapi.api.models.Personas
import com.moviles.practicaapi.R
import com.moviles.practicaapi.models.Post
import com.moviles.practicaapi.repositories.PersonaRepository
import com.moviles.practicaapi.ui.adapters.PersonaAdapter


class MainActivity : AppCompatActivity(), PersonaRepository.PersonaListListener,
    PersonaAdapter.PersonaListener,
    PersonaRepository.DeletePersonaListener,
    PersonaRepository.EditPersonaListener {
    private lateinit var btnCallApi: Button
    private lateinit var lstPosts: RecyclerView
    private lateinit var btnCrearPersona: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnCallApi = findViewById(R.id.btnCallApi)
        lstPosts = findViewById(R.id.lstPosts)
        btnCrearPersona = findViewById(R.id.btnCrear)
        setupEventListeners()
        callPostListApi()
    }

    private fun setupEventListeners() {
        btnCallApi.setOnClickListener {
            callPostListApi()
        }
        btnCrearPersona.setOnClickListener {
            val intent = Intent(this, FormPersona::class.java)
            startActivity(intent)
        }
    }

    //#region PostList API
    private fun callPostListApi() {
        PersonaRepository.getPersonas(this)
    }

    override fun onPersonaListSuccess(personas: List<Personas>?) {
        val adapter = PersonaAdapter(personas as ArrayList<Personas>, this)
        lstPosts.layoutManager =
            LinearLayoutManager(this@MainActivity)
        lstPosts.adapter = adapter
    }

    override fun onPersonaListFailure(t: Throwable) {
        Toast.makeText(this@MainActivity, t.message, Toast.LENGTH_SHORT).show()
    }

    override fun onItemEdit(persona: Personas) {
        val intent = Intent(this, FormPersona::class.java)
        intent.putExtra("persona", persona)
        startActivity(intent)
    }

    override fun onItemDelete(persona: Personas) {
        PersonaRepository.deletePersona(persona.id, this)
    }

    override fun onDeletePersonaSuccess(personas: Personas?) {
        Toast.makeText(this@MainActivity, "Persona eliminada", Toast.LENGTH_SHORT).show()
    }

    override fun onDeletePersonaFailure(t: Throwable) {
        Toast.makeText(this@MainActivity, t.message, Toast.LENGTH_SHORT).show()
    }

    override fun onEditPersonaSuccess(personas: Personas?) {
        Toast.makeText(this@MainActivity, "Persona editada", Toast.LENGTH_SHORT).show()
    }

    override fun onEditPersonaFailure(t: Throwable) {
        Toast.makeText(this@MainActivity, t.message, Toast.LENGTH_SHORT).show()
    }

}