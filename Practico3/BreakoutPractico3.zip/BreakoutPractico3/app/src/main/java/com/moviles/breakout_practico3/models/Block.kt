package com.moviles.breakout_practico3.models

data class Block(
    var x: Float,
    var y: Float,
    var side: Float,
    var height: Float,
    val color: Int
) :java.io.Serializable {

}