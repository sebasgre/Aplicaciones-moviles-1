package com.moviles.breakout_practico3.ui.components

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import com.moviles.breakout_practico3.models.Ball
import com.moviles.breakout_practico3.models.Block
import com.moviles.breakout_practico3.ui.activities.GameOverActivity
import com.moviles.breakout_practico3.ui.activities.MainActivity
import com.moviles.breakout_practico3.ui.activities.WinActivity


class MyCanvas(context: Context?, attrs: AttributeSet?) : View(context, attrs) {
    private val objPaint: Paint = Paint()
    private var value: MainActivity = MainActivity()
    var bitmap: Bitmap? = null

    private var score = 0


    private var ball: Ball = Ball(100f, 1400f, 80f, 100f, 100f)

    var game = true

    private var blockList: MutableList<Block> = mutableListOf()


    private var crowd = Block(500f, 1700f, 200f, 50f, Color.GREEN)
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    }


    public fun addBlock(lista: MutableList<Block>) {
        blockList = lista
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        objPaint.strokeWidth = 10f
        objPaint.color = Color.GREEN

        canvas?.drawOval(
            ball.x,
            ball.y,
            ball.x + ball.radio,
            ball.y + ball.radio,
            objPaint
        )

        canvas?.drawRect(
            crowd.x,
            crowd.y,
            crowd.x + crowd.side - 50,
            crowd.y + crowd.height,
            objPaint
        )

        objPaint.color = Color.WHITE


        for (block in blockList) {
            objPaint.color = block.color
            canvas?.drawRect(
                block.x,
                block.y,
                block.x + block.side,
                block.y + block.height,
                objPaint
            )
        }


        bitmap?.let {
            canvas?.drawBitmap(it, 0f, 0f, objPaint)
        }
        if (blockList.size == 0) {
            val intent = Intent(context, WinActivity::class.java)
            intent.putExtra("score", score)
            invalidate()
            context.startActivity(intent)
        }
        if (!game) {
            val intent = Intent(context, GameOverActivity::class.java)
            intent.putExtra("score", score)
            invalidate()
            context.startActivity(intent)
        }

        objPaint.textSize = 75f
        canvas?.drawText("Score: $score", 500f, 900f, objPaint)
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        //check if the user is touching the crowd
        when (event?.action) {

            MotionEvent.ACTION_DOWN -> {
                if (!game) {
                    resetBall()
                } else {
                    crowd.x = event.x
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (!game) {
                } else {
                    crowd.x = event.x - 50
                    invalidate()
                }
            }
        }
        return true
    }

    private fun resetBall() {
        xMove = 0f
        yMove = -10f
        ball.x = 400f
        ball.y = 1400f
        game = true
    }

    private var xMove = 0f
    private var yMove = -10f

    fun moveBall() {

        //check if ball is out of bounds
        if (ball.y >= 2000f) {
            game = false
            invalidate()
        }
        if (game) {
            ball.x += xMove
            ball.y += yMove

            if (ball.x + ball.radio >= width || ball.x <= 0) {
                xMove *= -1
            }
            if (ball.y <= 0) {
                yMove = 10f
            }

            if (ball.y + ball.radio >= crowd.y && ball.x + ball.radio >= crowd.x && ball.x <= crowd.x + crowd.side - 50) {
                if (ball.y + ball.radio <= crowd.y + crowd.height && ball.x + ball.radio <= crowd.x + crowd.side) {
                    yMove = -10f
                }
            }
            var removeBlock: Block? = null
            //check if ball is hitting a block and remove it
            for (block in blockList.iterator()) {
                if (ball.x + ball.radio + 10 >= block.x && ball.x <= block.x + block.side) {
                    if (ball.y + ball.radio + 10 >= block.y && ball.y <= block.y + block.height) {
                        removeBlock = block
                        if (ball.y > block.y) {
                            yMove = 10f
                        } else {
                            yMove = -10f
                        }
                        if (ball.x > block.x) {
                            xMove = 10f
                        } else {
                            xMove = -10f
                        }
                    }
                }
            }
            if (removeBlock != null) {
                blockList.remove(removeBlock)
                score++
            }
            invalidate()
        }
    }
}