package com.moviles.breakout_practico3.ui.activities

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.moviles.breakout_practico3.R
import com.moviles.breakout_practico3.models.Block
import com.moviles.breakout_practico3.ui.components.MyApplication
import com.moviles.breakout_practico3.ui.components.MyCanvas
import java.util.*


class GameActivity : AppCompatActivity() {
    private lateinit var myCanvas: MyCanvas

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
        myCanvas = findViewById(R.id.myCanvas)
        //get screen width and height
        val displayMetrics = resources.displayMetrics
        val width = displayMetrics.widthPixels
        var speed = (this.application as MyApplication).getSpeed()
        val blockList = mutableListOf<Block>()

        for (y in 1..1) {
            val color = Color.rgb(255,140,0)

            for (i in 1..1) {
                blockList.add(Block((i * (125f)), (y * 75f), width / 10f, 50f, color))
            }
        }

        myCanvas.addBlock(blockList)
        //create a thread and move every 1000ms

        val thread = Thread {
            while (true) {
                Thread.sleep(speed.toLong())
                myCanvas.moveBall()
            }
        }
        thread.start()
    }

}