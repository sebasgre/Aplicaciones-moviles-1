package com.moviles.breakout_practico3.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import com.moviles.breakout_practico3.R
import com.moviles.breakout_practico3.ui.components.MyApplication


class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    private lateinit var btnPlay: Button
    private lateinit var btnExit: Button
    private lateinit var spinner: Spinner
    private  lateinit var options: ArrayAdapter<String>



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnPlay = findViewById(R.id.btnPlay)
        btnExit = findViewById(R.id.btnExit)
        spinner = findViewById(R.id.spinner)
        setupListeners()

    }

    private fun setupListeners() {
        btnPlay.setOnClickListener {
            val intent = Intent(this, GameActivity::class.java)
            startActivity(intent)
        }
        btnExit.setOnClickListener {
            finish()
        }
       options = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Easy", "Medium", "Hard")
        )
        spinner.onItemSelectedListener = this
        spinner.adapter = options
    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
        val selectedItem = options.getItem(position)
        when(selectedItem){
            "Easy" -> (this.application as MyApplication).setSpeed(20)
            "Medium" -> (this.application as MyApplication).setSpeed(15)
            "Hard" -> (this.application as MyApplication).setSpeed(7)
        }
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {

    }



}

