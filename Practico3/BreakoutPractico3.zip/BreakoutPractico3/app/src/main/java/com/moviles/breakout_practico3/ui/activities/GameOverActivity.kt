package com.moviles.breakout_practico3.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.moviles.breakout_practico3.R

class GameOverActivity : AppCompatActivity() {
    private lateinit var lblScore: TextView
    private lateinit var btnMenu: Button
    private lateinit var btnExit: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_over)
        lblScore = findViewById(R.id.lblScore2)
        loadScore()
        btnMenu = findViewById(R.id.btnMenu)
        btnExit = findViewById(R.id.btnExit2)
        btnMenu.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        btnExit.setOnClickListener {
            finish()
        }
    }

    private fun loadScore() {
        val score = intent.getIntExtra("score", 0)
        lblScore.text = score.toString()
    }
}