package com.moviles.breakout_practico3.models

data class Ball(
    var x: Float,
    var y: Float,
    var radio: Float,
    var vX: Float,
    var vY: Float
) :java.io.Serializable {

}