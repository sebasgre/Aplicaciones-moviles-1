package com.moviles.breakout_practico3.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.moviles.breakout_practico3.R

class WinActivity : AppCompatActivity() {
    private lateinit var lblScore: TextView
    private lateinit var btnExit: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_win)
        lblScore = findViewById(R.id.lblScore)
        btnExit = findViewById(R.id.btnExit3)
        loadScore()
        btnExit.setOnClickListener {
            finish()
        }
    }

    private fun loadScore() {
        val score = intent.getIntExtra("score", 0)
        lblScore.text = score.toString()
    }
}