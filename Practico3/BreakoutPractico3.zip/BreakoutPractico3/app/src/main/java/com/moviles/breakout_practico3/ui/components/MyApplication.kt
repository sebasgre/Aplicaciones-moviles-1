package com.moviles.breakout_practico3.ui.components

import android.app.Application

class MyApplication: Application() {
    private var speed: Int = 16

    public fun setSpeed(speed: Int) {
        this.speed = speed
    }
    public fun getSpeed(): Int {
        return speed
    }
}