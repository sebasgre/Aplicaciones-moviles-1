package com.moviles.practico2_recetario.models

import java.io.Serializable

data class Foods(
    var id: Int,
    var name: String,
    var foto: Int,
    var description: String,
    var listIngredients: ArrayList<String>
) : Serializable {
}