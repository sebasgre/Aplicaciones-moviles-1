package com.moviles.practico2_recetario.ui.adapters

import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.moviles.practico2_recetario.R
import com.moviles.practico2_recetario.models.Foods

class FoodRecyclerAdapter(val data: ArrayList<Foods>, val lisener: OnFoodClickListener) :
    RecyclerView.Adapter<FoodRecyclerAdapter.FoodViewHolder>() {

    class FoodViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val btnFood: Button
        init {
            btnFood = itemView.findViewById(R.id.btnFood)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val view = View.inflate(parent.context, R.layout.food_item_layout, null)
        return FoodViewHolder(view)
    }

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        val food = data[position]
        holder.btnFood.text = food.name
        holder.btnFood.setOnClickListener {
            lisener.onFoodClick(food)
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }

    interface OnFoodClickListener {
        fun onFoodClick(food: Foods)
    }
}