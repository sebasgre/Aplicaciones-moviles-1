package com.moviles.practico2_recetario.ui.activities

import android.content.Intent
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.moviles.practico2_recetario.R
import com.moviles.practico2_recetario.models.Ingredients
import com.moviles.practico2_recetario.ui.adapters.IngredientsRecyclerAdapter

class MainActivity : AppCompatActivity() {
    private lateinit var lstList: RecyclerView
    private var selectList: ArrayList<String> = arrayListOf()
    private lateinit var btnBuscar: Button
    var ingredients = arrayListOf<Ingredients>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnBuscar = findViewById(R.id.btnBuscar)
        lstList = findViewById(R.id.lstRecetario)
        setupListView()
        btnBuscar.setOnClickListener {
            val intent = Intent(this, FoodActivity::class.java)
            ingredientsSelected()
            if (selectList.size > 0) {
                intent.putExtra("ingredients", selectList)
                startActivity(intent)
            }else {
                Toast.makeText(this, "Debe seleccionar al menos un ingrediente", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun ingredientsSelected() {
        for (ingredient in ingredients) {
            if (ingredient.isSelected) {
                selectList.add(ingredient.name)
                Log.d("ingredientes", ingredient.name)
            }else {
                selectList.remove(ingredient.name)
                Log.d("ingredientes eliminados", ingredient.name)
            }
        }
    }


    private fun setupListView() {
        ingredients = arrayListOf(
            Ingredients(
                1,
                "carne",
                R.drawable.carne,
                false
            ),
            Ingredients(
                2,
                "pollo",
                R.drawable.pollo,
                false
            ),
            Ingredients(
                3,
                "papas",
                R.drawable.papa,
                false
            ),
            Ingredients(
                4,
                "arroz",
                R.drawable.arroz,
                false
            ),
            Ingredients(
                5,
                "lechuga",
                R.drawable.lechuga,
                false
            ),
            Ingredients(
                6,
                "tomate",
                R.drawable.tomate,
                false
            ),
            Ingredients(
                7,
                "leche",
                R.drawable.leche,
                false
            ),
            Ingredients(
                8,
                "champiñones",
                R.drawable.champi,
                false
            )
        )
        val adapter = IngredientsRecyclerAdapter(ingredients)
        lstList.layoutManager = GridLayoutManager(this, 2)
        lstList.adapter = adapter
    }

}