package com.moviles.practico2_recetario.ui.adapters

import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.moviles.practico2_recetario.R
import com.moviles.practico2_recetario.models.Ingredients

class IngredientsRecyclerAdapter(val data: ArrayList<Ingredients>) :
    RecyclerView.Adapter<IngredientsRecyclerAdapter.RecetarioViewHolder>() {
    class RecetarioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img: ImageView
        init {
            img = itemView.findViewById(R.id.img)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecetarioViewHolder {
        val view = View.inflate(parent.context, R.layout.recetario_item_layout, null)
        return RecetarioViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecetarioViewHolder, position: Int) {
        val recetario = data[position]
        holder.img.setImageResource(recetario.foto)
        holder.img.setOnClickListener {
            recetario.isSelected = !recetario.isSelected
            if (recetario.isSelected) {
                holder.img.setBackgroundColor(Color.parseColor("#B2FF59"))
            } else {
                holder.img.setBackgroundColor(Color.parseColor("#ffffff"))
            }
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }

}