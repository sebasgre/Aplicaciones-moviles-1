package com.moviles.practico2_recetario.models

import java.io.Serializable

data class Ingredients(
    var id: Int,
    var name: String,
    var foto: Int,
    var isSelected: Boolean
) :Serializable {
}