package com.moviles.practico2_recetario.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.moviles.practico2_recetario.R
import com.moviles.practico2_recetario.models.Foods
import com.moviles.practico2_recetario.models.Ingredients
import com.moviles.practico2_recetario.ui.adapters.FoodRecyclerAdapter

class FoodActivity : AppCompatActivity(), FoodRecyclerAdapter.OnFoodClickListener {
    private lateinit var lstFoods: RecyclerView
    private lateinit var btnBack: ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food)
        lstFoods = findViewById(R.id.lstFood)
        btnBack = findViewById(R.id.btnBack1)
        btnBack.setOnClickListener {
            finish()
        }
        setupListView()
    }

    private fun setupListView() {
        var foods = arrayListOf<Foods>(
            Foods(1, "Arroz con leche", R.drawable.arroz_con_leche, "1 taza de arroz, 1 litro de leche, 1 taza de azúcar, 1 cucharadita de canela, 1 cucharadita de vainilla, 1 cucharadita de sal, 1 cucharada de mantequilla", arrayListOf("arroz", "leche", "azucar", "canela", "vainilla", "sal", "mantequilla")),
            Foods(2, "Pollo con papas", R.drawable.pollo_con_papas, "1 pollo, 1 kilo de papas, 1 cebolla, 1 cucharada de ajo, 1 cucharada de perejil, 1 cucharada de sal, 1 cucharada de pimienta, 1 cucharada de aceite de oliva", arrayListOf("pollo", "papas", "cebolla", "ajo", "perejil", "sal", "pimienta", "aceite de oliva")),
            Foods(3, "Carne con arroz", R.drawable.carne_con_arroz, "1 kilo de carne, 1 taza de arroz, 1 cebolla, 1 cucharada de ajo, 1 cucharada de perejil, 1 cucharada de sal, 1 cucharada de pimienta, 1 cucharada de aceite de oliva", arrayListOf("carne", "arroz", "cebolla", "ajo", "perejil", "sal", "pimienta", "aceite de oliva")),
            Foods(4, "Carne con ensalada", R.drawable.carne_con_lechuga_y_tomate, "1 kilo de carne, 1 taza de lechuga, 1 tomate, 1 cucharada de ajo, 1 cucharada de perejil, 1 cucharada de sal, 1 cucharada de pimienta, 1 cucharada de aceite de oliva", arrayListOf("carne", "lechuga", "tomate", "ajo", "perejil", "sal", "pimienta", "aceite de oliva")),
            Foods(5, "Pollo con champiñones", R.drawable.pollo_con_champi, "1 pollo, 1 kilo de champiñones, 1 cebolla, 1 cucharada de ajo, 1 cucharada de perejil, 1 cucharada de sal, 1 cucharada de pimienta, 1 cucharada de aceite de oliva", arrayListOf("pollo", "champiñones", "cebolla", "ajo", "perejil", "sal", "pimienta", "aceite de oliva")),
        )
        val ingredientsSelected = intent.getSerializableExtra("ingredients") as ArrayList<*>
        for (ingredient in ingredientsSelected) {
            foods = foods.filter {it -> it.listIngredients.contains(ingredient)} as ArrayList<Foods>
        }
        Log.d("foods", foods.toString())
        val adapter = FoodRecyclerAdapter(foods, this)
        lstFoods.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        lstFoods.adapter = adapter
    }

    override fun onFoodClick(food: Foods) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra("food", food)
        startActivity(intent)
    }
}