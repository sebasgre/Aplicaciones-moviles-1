package com.moviles.practico2_recetario.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.moviles.practico2_recetario.R
import com.moviles.practico2_recetario.models.Foods

class DetailActivity : AppCompatActivity() {
    private lateinit var lblTitle: TextView
    private lateinit var img: ImageView
    private lateinit var lblIngredients: TextView
    private lateinit var lblPreparation: TextView
    private lateinit var btnBack: ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        lblTitle = findViewById(R.id.lblTitulo)
        img = findViewById(R.id.imgFood)
        lblIngredients = findViewById(R.id.lblIngredients)
        lblPreparation = findViewById(R.id.lblPreparation)
        loadData()
        btnBack = findViewById(R.id.btnBack2)
        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun loadData() {
        var food = intent.getSerializableExtra("food") as Foods;
        lblTitle.text = food.name
        img.setImageResource(food.foto)
        for (i in food.listIngredients) {
            lblIngredients.append("$i ")
        }
        lblPreparation.text = food.description
    }
}