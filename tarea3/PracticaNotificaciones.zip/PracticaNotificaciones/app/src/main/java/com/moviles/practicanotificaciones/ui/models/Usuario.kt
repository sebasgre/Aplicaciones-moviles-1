package com.moviles.practicanotificaciones.ui.models

class Usuario(
    var id: Int = 0,
    var idUsuario: Int = 0,
    var notificacionId: String = ""
) : java.io.Serializable {

}