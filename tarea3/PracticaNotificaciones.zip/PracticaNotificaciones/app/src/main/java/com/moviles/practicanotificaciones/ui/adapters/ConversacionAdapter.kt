package com.moviles.practicanotificaciones.ui.adapters

class ConversacionAdapter {
}