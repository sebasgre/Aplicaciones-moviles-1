package com.moviles.practicanotificaciones.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import com.moviles.practicanotificaciones.R
import com.moviles.practicanotificaciones.repositories.ChatRepository
import com.moviles.practicanotificaciones.ui.models.Conversaciones
import com.moviles.practicanotificaciones.ui.models.Usuario

class AddConversation : AppCompatActivity(), ChatRepository.AddChat {
    private lateinit var idReceptor: EditText
    private lateinit var guardar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_conversation)
        idReceptor = findViewById(R.id.txtreceptor)
        guardar = findViewById(R.id.btnGuardar)
        setupEventListeners()
    }

    private fun setupEventListeners() {
        val usuario = intent.getStringExtra("usuario") as Usuario?
        val conversa = Conversaciones(
            idUsuarioEnvio = usuario?.idUsuario,
            idUsuarioReceptor = idReceptor.text.toString()
        )
        guardar.setOnClickListener {
            ChatRepository.addChat(usuario.toString(), idReceptor.text.toString(), this)
        }
    }

    override fun onAddChatSuccess(conversacion: Conversaciones?) {
        Log.e("Success", "Conversacion agregada!")
    }

    override fun onAddChatFailure(error: Throwable) {
        Log.e("Error", error.message.toString())
    }
}