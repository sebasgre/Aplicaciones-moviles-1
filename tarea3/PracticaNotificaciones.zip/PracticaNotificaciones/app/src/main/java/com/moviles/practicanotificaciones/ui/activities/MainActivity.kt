package com.moviles.practicanotificaciones.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.moviles.practicanotificaciones.R
import com.moviles.practicanotificaciones.repositories.ChatRepository
import com.moviles.practicanotificaciones.ui.models.Usuario

class MainActivity : AppCompatActivity(), ChatRepository.LoginUser {
    private lateinit var token: EditText
    private lateinit var next: Button
    private var user: Int = 29

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        token = findViewById(R.id.txtToken)
        next = findViewById(R.id.btnnext)
        setupFireBase()
        setupEventListeners()
    }

    private fun setupEventListeners() {
        next.setOnClickListener {
            val intent = Intent(this, AddConversation::class.java)
            val Usuario = Usuario(
                idUsuario = user,
                notificacionId = token.text.toString()
            )
            if (Usuario != null) {
                intent.putExtra("usuario", Usuario)
                ChatRepository.login(Usuario, this)
                startActivity(intent)
            } else {
                Toast.makeText(
                    this,
                    "No se pudo iniciar sesion intente de nuevo",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onLoginSuccess(usuario: Usuario?) {
        Toast.makeText(this, "Bienvenido", Toast.LENGTH_SHORT).show()
    }

    override fun onLoginFailure(error: Throwable) {
        Log.e("Error", error.message.toString())
    }
}

private fun setupFireBase() {
    // el token es un identificador unico para cada dispositivo que se registra en la app
    FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
        if (!task.isSuccessful) {
            Log.w("TOKEN", "Fetching FCM registration token failed", task.exception)
            return@OnCompleteListener
        }

        // Get new FCM registration token
        val token = task.result as String

        // Log and toast
        Log.d("TOKEN", token)
    })
}
