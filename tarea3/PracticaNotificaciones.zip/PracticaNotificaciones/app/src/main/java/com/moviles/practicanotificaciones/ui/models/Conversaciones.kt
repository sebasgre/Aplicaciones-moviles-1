package com.moviles.practicanotificaciones.ui.models

class Conversaciones(
    var id: Int = 0,
    var idUsuarioEnvio: Int = 0,
    var idUsuarioReceptor: Int = 0
) : java.io.Serializable {

}