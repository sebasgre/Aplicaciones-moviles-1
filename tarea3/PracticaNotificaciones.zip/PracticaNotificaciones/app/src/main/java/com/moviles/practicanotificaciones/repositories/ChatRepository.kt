package com.moviles.practicanotificaciones.repositories

import com.moviles.practicanotificaciones.api.ChatPlaceHolderApi
import com.moviles.practicanotificaciones.ui.models.Conversaciones
import com.moviles.practicanotificaciones.ui.models.Usuario
import retrofit2.Call

object ChatRepository {
    fun login(usuario: Usuario, listener: LoginUser) {
        val retrofit = RetrofitRepository.getRetrofit()
        val jsonPlaceHolderAPI = retrofit.create(ChatPlaceHolderApi::class.java)
        jsonPlaceHolderAPI.login(usuario).enqueue(object : retrofit2.Callback<Usuario> {
            override fun onResponse(
                call: Call<Usuario>,
                response: retrofit2.Response<Usuario>
            ) {
                if (response.isSuccessful) {
                    listener.onLoginSuccess(response.body())
                }
            }

            override fun onFailure(call: Call<Usuario>, t: Throwable) {
                listener.onLoginFailure(t)
            }
        })
    }

    fun addChat(conversacion: Conversaciones, listener: AddChat) {
        val retrofit = RetrofitRepository.getRetrofit()
        val jsonPlaceHolderAPI = retrofit.create(ChatPlaceHolderApi::class.java)
        jsonPlaceHolderAPI.addChat(conversacion).enqueue(object : retrofit2.Callback<Conversaciones> {
            override fun onResponse(
                call: Call<Conversaciones>,
                response: retrofit2.Response<Conversaciones>
            ) {
                if (response.isSuccessful) {
                    listener.onAddChatSuccess(response.body())
                }
            }

            override fun onFailure(call: Call<Conversaciones>, t: Throwable) {
                listener.onAddChatFailure(t)
            }
        })
    }

    interface LoginUser {
        fun onLoginSuccess(usuario: Usuario?)
        fun onLoginFailure(error: Throwable)
    }

    interface AddChat {
        fun onAddChatSuccess(conversacion: Conversaciones?)
        fun onAddChatFailure(error: Throwable)
    }
}