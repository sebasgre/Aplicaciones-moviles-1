package com.moviles.practicanotificaciones.api

import com.moviles.practicanotificaciones.ui.models.Conversaciones
import com.moviles.practicanotificaciones.ui.models.Usuario
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ChatPlaceHolderApi {
    @POST("iniciarsesion")
    fun login(@Body usuario: Usuario): Call<Usuario>

    @POST("addmessage")
    fun addChat(@Body conversacion: Conversaciones): Call<Conversaciones>

    @GET("conversacion")
    fun getChats(): Call<List<Conversaciones>>

}