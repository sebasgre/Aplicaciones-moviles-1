package com.moviles.burguerweek.dal.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.moviles.burguerweek.dal.entities.Usuarios
@Dao
interface UsuarioDao {
    @Query("SELECT * FROM usuarios")
    fun getAll(): List<Usuarios>

    @Query("SELECT * FROM usuarios WHERE id = :id")
    fun getById(id: Int): Usuarios?

    @Insert
    fun insert(usuario: Usuarios)
}