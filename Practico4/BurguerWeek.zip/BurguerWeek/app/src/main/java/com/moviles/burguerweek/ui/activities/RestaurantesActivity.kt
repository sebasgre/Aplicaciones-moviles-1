package com.moviles.burguerweek.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.moviles.burguerweek.R
import com.moviles.burguerweek.dal.entities.Restaurantes
import com.moviles.burguerweek.repository.RestauranteRepository
import com.moviles.burguerweek.ui.adapters.RestauranteAdapter

class RestaurantesActivity : AppCompatActivity(), RestauranteAdapter.onRestauranteListener {
    private lateinit var adapter: RestauranteAdapter
    private lateinit var lstRestaurantes: RecyclerView
    private lateinit var bundle: Bundle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_restaurantes)
        lstRestaurantes = findViewById(R.id.lstRestaurantes)
        bundle = intent.extras!!
        if (bundle != null) {
            Toast.makeText(this, "Bienvenido ${bundle.getString("usuario")}", Toast.LENGTH_LONG)
                .show()
        }
        loadData()
        setupRecyclerView()
    }

    private fun loadData() {
        val restaurante1 = Restaurantes(
            "Krusty Burger",
            "https://static.wikia.nocookie.net/lossimpson/images/5/5c/Krusty_Burger.png/revision/latest?cb=20150920213438&path-prefix=es"
        )
        val restaurante2 = Restaurantes(
            "McDonald's",
            "https://www.visafranchise.com/wp-content/uploads/2022/02/mdo.jpg"
        )
        val restaurante3 = Restaurantes(
            "Burger King",
            "https://media-cdn.tripadvisor.com/media/photo-s/0e/01/8d/17/good-service-for-a-change.jpg"
        )
        val restaurante4 = Restaurantes(
            "Toby",
            "https://www.hashplace.com/images/lugares/2012-04/hamburguesas-toby-2-8617.jpg"
        )
        val restaurante5 = Restaurantes(
            "In-N-Out",
            "https://www.eatthis.com/wp-content/uploads/sites/4/2021/11/in-n-out-exterior.jpg?quality=82&strip=all"
        )
//        RestauranteRepository.insert(restaurante1, this)
//        RestauranteRepository.insert(restaurante2, this)
//        RestauranteRepository.insert(restaurante3, this)
//        RestauranteRepository.insert(restaurante4, this)
//        RestauranteRepository.insert(restaurante5, this)
    }

    private fun setupRecyclerView() {
        val restaurantes = RestauranteRepository.getAllRestaurantes(this)
        adapter = RestauranteAdapter(restaurantes as ArrayList<Restaurantes>, this)
        lstRestaurantes.adapter = adapter
        lstRestaurantes.layoutManager = LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()
        refreshData()
    }

    private fun refreshData() {
        val products = RestauranteRepository.getAllRestaurantes(this)
        adapter.refreshData(products)
    }

    override fun onIrRestauranteClick(restaurante: Restaurantes) {
        val bundle2 = Bundle()
        bundle2.putInt("restauranteId", restaurante.id)
        if (bundle != null) {
            bundle2.putInt("usuarioId", bundle.getInt("usuarioId"))
        }
        val intent = Intent(this, HamburguesasActivity::class.java)
        intent.putExtras(bundle2)
        startActivity(intent)
    }

}