package com.moviles.burguerweek.dal.dao

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.Query
import com.moviles.burguerweek.dal.entities.Hamburguesas

@Dao
interface HamburguesasDao {
    @Query("SELECT * FROM hamburguesas")
    fun getAll(): List<Hamburguesas>

    @Query("SELECT * FROM hamburguesas WHERE id = :id")
    fun getById(id: Int): Hamburguesas?

    @Query("SELECT * FROM hamburguesas WHERE idRestaurante = :id")
    fun getByRestaurante(id: Int): List<Hamburguesas>?

    @Insert
    fun insert(hamburguesa: Hamburguesas)
}