package com.moviles.burguerweek.repository

import android.content.Context
import com.moviles.burguerweek.dal.db.AppDataBase
import com.moviles.burguerweek.dal.entities.Reviews

object ReviewRepository {
    fun getAllReviews(context: Context): List<Reviews> {
        val reviewDao = AppDataBase.getDatabase(context).reviewDao()
        return reviewDao.getAll()
    }

    fun getReviewById(id: Int, context: Context): Reviews? {
        val reviewDao = AppDataBase.getDatabase(context).reviewDao()
        return reviewDao.getById(id)
    }

    fun getReviewsByHamburguesa(id: Int, context: Context): List<Reviews> {
        val reviewDao = AppDataBase.getDatabase(context).reviewDao()
        return reviewDao.getReviewsByHamburguesa(id)
    }

    fun insert(review: Reviews, context: Context) {
        val reviewDao = AppDataBase.getDatabase(context).reviewDao()
        reviewDao.insert(review)
    }

    fun update(review: Reviews, context: Context) {
        val reviewDao = AppDataBase.getDatabase(context).reviewDao()
        reviewDao.update(review)
    }

    fun delete(review: Reviews, context: Context) {
        val reviewDao = AppDataBase.getDatabase(context).reviewDao()
        reviewDao.delete(review)
    }


}