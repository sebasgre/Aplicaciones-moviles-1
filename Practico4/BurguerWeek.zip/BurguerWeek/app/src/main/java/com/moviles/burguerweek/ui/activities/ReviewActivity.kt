package com.moviles.burguerweek.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.moviles.burguerweek.R
import com.moviles.burguerweek.dal.entities.Reviews
import com.moviles.burguerweek.dal.entities.Usuarios
import com.moviles.burguerweek.repository.ReviewRepository
import com.moviles.burguerweek.repository.UsuarioRepository

class ReviewActivity : AppCompatActivity() {
    private lateinit var lblBurgerName: TextView
    private lateinit var imgBurger: ImageView
    private lateinit var rate: RatingBar
    private lateinit var lblDescriptionComentario: EditText
    private lateinit var btnComentar: Button
    private lateinit var bundle: Bundle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review)
        lblBurgerName = findViewById(R.id.lblNombreComentario)
        imgBurger = findViewById(R.id.imgBurgerFoto)
        rate = findViewById(R.id.ratingBar)
        lblDescriptionComentario = findViewById(R.id.txtDescripcionComentario)
        btnComentar = findViewById(R.id.btnGuardarComentario)
        bundle = intent.extras!!
        loadData()
        setupEventListeners()
    }

    private fun loadData() {
        if (bundle != null) {
            val nombre = bundle.getString("burgerName")
            val foto = bundle.getString("burgerFoto")
            lblBurgerName.text = nombre
            Glide.with(this).load(foto).into(imgBurger)
        }
    }

    private fun setupEventListeners() {
        btnComentar.setOnClickListener {
            if (bundle != null) {
                val idUsuario = bundle.getInt("usuarioId")
                val idBurger = bundle.getInt("burgerId")
                val rating = rate.rating
                val descripcion = lblDescriptionComentario.text.toString()
                if (descripcion.isNotEmpty() && rating > 0) {
                    val usuario = UsuarioRepository.getUsuarioById(idUsuario, this)
                    usuario!!.IsEaten = true
                    val comentario = Reviews(idUsuario, idBurger, rating, descripcion)
                    ReviewRepository.insert(comentario, this)
                    Log.d("Comentario", "Comentario guardado")
                    finish()
                }
            }
        }
    }
}