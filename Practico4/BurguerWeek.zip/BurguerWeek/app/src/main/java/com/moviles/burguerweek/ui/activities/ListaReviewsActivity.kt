package com.moviles.burguerweek.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.moviles.burguerweek.R
import com.moviles.burguerweek.dal.entities.Reviews
import com.moviles.burguerweek.repository.ReviewRepository
import com.moviles.burguerweek.ui.adapters.ReviewListAdapter

class ListaReviewsActivity : AppCompatActivity(), ReviewListAdapter.onReviewListener {
    private lateinit var adapter: ReviewListAdapter
    private lateinit var lstListReview: RecyclerView
    private lateinit var bundle: Bundle
    private lateinit var lblNombre: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_reviews)
        lstListReview = findViewById(R.id.lstListReviews)

        bundle = intent.extras!!
        if (bundle != null) {
            setupEventListeners()
        }
    }

    private fun setupEventListeners() {
        val usuarioId = bundle.getInt("usuarioId")
        val burgerId = bundle.getInt("burgerId")
        val reviews = ReviewRepository.getReviewsByHamburguesa(burgerId, this)
        adapter = ReviewListAdapter(reviews as ArrayList<Reviews>, this)
        lstListReview.adapter = adapter
        lstListReview.layoutManager = LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()
        refreshData()
    }

    private fun refreshData() {
        val products = ReviewRepository.getReviewsByHamburguesa(bundle.getInt("burgerId"), this)
        adapter.refreshData(products)
    }

    override fun onReviewEdit(review: Reviews) {

    }

    override fun onReviewDelete(review: Reviews) {

    }
}