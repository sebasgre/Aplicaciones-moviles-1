package com.moviles.burguerweek.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Log.INFO
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.moviles.burguerweek.R
import com.moviles.burguerweek.dal.entities.Hamburguesas
import com.moviles.burguerweek.repository.HamburguesaRepository
import com.moviles.burguerweek.ui.adapters.HamburguesaAdapter
import java.util.logging.Level.INFO

class HamburguesasActivity : AppCompatActivity(), HamburguesaAdapter.onBurgerListeners {
    private lateinit var adapter: HamburguesaAdapter
    private lateinit var lstBurgers: RecyclerView
    private lateinit var bundle: Bundle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hamburguesas)
        lstBurgers = findViewById(R.id.lsltBurgers)
        bundle = intent.extras!!
        if (bundle != null) {
            loadData()
            setupRecyclerView()
        }
    }

    private fun setupRecyclerView() {
        Log.d("idRestaurante", bundle.getInt("restauranteId").toString())
        val restauranteId = bundle.getInt("restauranteId")
        val hamburguesas =
            HamburguesaRepository.getHamburguesaByRestaurante(restauranteId, this)
        adapter = HamburguesaAdapter(hamburguesas as ArrayList<Hamburguesas>, this)
        lstBurgers.adapter = adapter
        lstBurgers.layoutManager = LinearLayoutManager(this)
    }

    private fun loadData() {
            val idRestaurante = bundle.getInt("restauranteId")
            val burger1 = Hamburguesas(
                "Clasica",
                "Carne de res, lechuga, tomate, cebolla, queso, mayonesa, ketchup, mostaza",
                "https://easyrecetas.com/wp-content/uploads/2020/05/Receta-de-Hamburguesa-Cl%C3%A1sica.jpg",
                idRestaurante
            )
            val burger2 = Hamburguesas(
                "Doble",
                "Carne de res, lechuga, tomate, cebolla, queso, mayonesa, ketchup, mostaza",
                "https://st.depositphotos.com/1884173/2999/i/600/depositphotos_29998659-stock-photo-classic-burgers.jpg",
                idRestaurante
            )
            val burger3 = Hamburguesas(
                "Barbacoa",
                "Carne de res, lechuga, tomate, cebolla, queso, mayonesa, ketchup, mostaza",
                "https://assets.unileversolutions.com/recipes-v2/233313.jpg",
                idRestaurante
            )
            val burger4 = Hamburguesas(
                "Pollo",
                "Pollo, lechuga, tomate, cebolla, queso, mayonesa, ketchup, mostaza",
                "https://e7.pngegg.com/pngimages/752/744/png-clipart-kfc-hamburger-chicken-sandwich-cheeseburger-crispy-fried-chicken-kfc-logo-food-recipe.png",
                idRestaurante
            )
            HamburguesaRepository.insert(burger1, this)
            HamburguesaRepository.insert(burger2, this)
            HamburguesaRepository.insert(burger3, this)
            HamburguesaRepository.insert(burger4, this)
    }

    override fun onResume() {
        super.onResume()
        refreshData()
    }

    private fun refreshData() {
        val products = HamburguesaRepository.getHamburguesaByRestaurante(bundle.getInt("restauranteId"), this)
        adapter.refreshData(products as ArrayList<Hamburguesas>)
    }

    override fun onComentarClick(comentar: Hamburguesas) {
        bundle.putString("burgerName", comentar.nombre)
        bundle.putString("burgerFoto", comentar.foto)
        bundle.putInt("burgerId", comentar.id)
        bundle.putInt("usuarioId", bundle.getInt("usuarioId"))
        val intent = Intent(this, ReviewActivity::class.java)
        intent.putExtras(bundle)
        startActivity(intent)
    }

    override fun onReviewClick(hamburguesa: Hamburguesas) {
        bundle.putInt("usuarioId", bundle.getInt("usuarioId"))
        bundle.putInt("burgerId", hamburguesa.id)
        val intent = Intent(this, ListaReviewsActivity::class.java)
        intent.putExtras(bundle)
        startActivity(intent)
    }
}