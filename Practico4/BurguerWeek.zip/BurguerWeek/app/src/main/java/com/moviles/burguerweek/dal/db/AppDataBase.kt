package com.moviles.burguerweek.dal.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room.databaseBuilder
import androidx.room.RoomDatabase
import com.moviles.burguerweek.dal.dao.HamburguesasDao
import com.moviles.burguerweek.dal.dao.RestaurantesDao
import com.moviles.burguerweek.dal.dao.ReviewDao
import com.moviles.burguerweek.dal.dao.UsuarioDao
import com.moviles.burguerweek.dal.entities.Hamburguesas
import com.moviles.burguerweek.dal.entities.Restaurantes
import com.moviles.burguerweek.dal.entities.Reviews
import com.moviles.burguerweek.dal.entities.Usuarios

@Database(
    entities = [Hamburguesas::class, Restaurantes::class, Reviews::class, Usuarios::class],
    version = 24
)
abstract class AppDataBase : RoomDatabase() {
    abstract  fun restaurantesDao(): RestaurantesDao
    abstract  fun hamburguesaDao(): HamburguesasDao
    abstract fun usuarioDao(): UsuarioDao
    abstract fun reviewDao(): ReviewDao

    companion object {
        private var instance: AppDataBase? = null

        fun getDatabase(context: Context): AppDataBase {
            if (instance == null) {
                instance = databaseBuilder(
                    context,
                    AppDataBase::class.java,
                    "burguer_week"
                )
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build()
            }
            return instance!!
        }
    }
}