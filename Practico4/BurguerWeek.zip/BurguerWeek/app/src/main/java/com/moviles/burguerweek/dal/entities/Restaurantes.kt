package com.moviles.burguerweek.dal.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Restaurantes(
    val nombre: String,
    val foto: String
) {
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0
}