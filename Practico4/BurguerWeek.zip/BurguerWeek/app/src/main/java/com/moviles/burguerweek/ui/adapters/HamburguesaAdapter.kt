package com.moviles.burguerweek.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.moviles.burguerweek.R
import com.moviles.burguerweek.dal.entities.Hamburguesas

class HamburguesaAdapter(val data: ArrayList<Hamburguesas>, val listener: onBurgerListeners) :
    RecyclerView.Adapter<HamburguesaAdapter.HamburguesaViewHolder>() {

    class HamburguesaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageHamburguesa: ImageView = itemView.findViewById(R.id.imageBurger)
        val nombreHamburguesa: TextView = itemView.findViewById(R.id.lblNombreBurger)
        val description: TextView = itemView.findViewById(R.id.txtDescription)
        val btnComentar: Button = itemView.findViewById(R.id.btnComentar)
        val btnReview: Button = itemView.findViewById(R.id.btnReviews)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HamburguesaViewHolder {
        val inlater = LayoutInflater.from(parent.context)
        val view = inlater.inflate(R.layout.hamburguesa_item_layout, parent, false)
        return HamburguesaViewHolder(view)
    }

    override fun onBindViewHolder(holder: HamburguesaViewHolder, position: Int) {
        val hamburguesa = data[position]
        val imagen = hamburguesa.foto
        Glide.with(holder.imageHamburguesa.context).load(imagen).into(holder.imageHamburguesa)
        holder.nombreHamburguesa.text = hamburguesa.nombre
        holder.description.text = hamburguesa.descripcion
        holder.btnComentar.setOnClickListener {
            listener.onComentarClick(hamburguesa)
        }
        holder.btnReview.setOnClickListener {
            listener.onReviewClick(hamburguesa)
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }

    fun refreshData(products: List<Hamburguesas>) {
        data.clear()
        data.addAll(products)
        notifyDataSetChanged()
    }

    interface onBurgerListeners {
        fun onComentarClick(comentar: Hamburguesas)
        fun onReviewClick(hamburguesa: Hamburguesas)
    }

}