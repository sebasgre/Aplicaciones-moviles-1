package com.moviles.burguerweek.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.moviles.burguerweek.R
import com.moviles.burguerweek.dal.entities.Restaurantes
import com.bumptech.glide.Glide

class RestauranteAdapter(val data: ArrayList<Restaurantes>, val listener: onRestauranteListener) :
    RecyclerView.Adapter<RestauranteAdapter.RestauranteViewHolder>() {
    class RestauranteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageRestaurante: ImageView = itemView.findViewById(R.id.imageRestaurante)
        val btnIrRestaurante: Button = itemView.findViewById(R.id.btnIrRestaurante)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RestauranteViewHolder {
        val inlater = LayoutInflater.from(parent.context)
        val view = inlater.inflate(R.layout.restaurante_item_layout, parent, false)
        return RestauranteViewHolder(view)
    }

    override fun onBindViewHolder(holder: RestauranteViewHolder, position: Int) {
        val restaurante = data[position]
        val imagen = restaurante.foto
        Glide.with(holder.imageRestaurante.context).load(imagen).into(holder.imageRestaurante)
        holder.btnIrRestaurante.text = restaurante.nombre
        holder.btnIrRestaurante.setOnClickListener {
            listener.onIrRestauranteClick(restaurante)
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }

    fun refreshData(products: List<Restaurantes>) {
        data.clear()
        data.addAll(products)
        notifyDataSetChanged()
    }

    interface onRestauranteListener {
        fun onIrRestauranteClick(restaurante: Restaurantes)
    }

}


