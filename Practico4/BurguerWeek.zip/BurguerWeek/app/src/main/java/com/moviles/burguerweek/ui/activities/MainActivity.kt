package com.moviles.burguerweek.ui.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.moviles.burguerweek.R
import com.moviles.burguerweek.repository.UsuarioRepository
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    private lateinit var correo: EditText
    private lateinit var contrasena: EditText
    private lateinit var crear: Button
    private lateinit var iniciar: Button
    private lateinit var lblError: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        correo = findViewById(R.id.correo2)
        contrasena = findViewById(R.id.contraseña2)
        crear = findViewById(R.id.btnCrear2)
        iniciar = findViewById(R.id.btnIngresar)
        lblError = findViewById(R.id.lblError2)
        setupEventListeners()
    }

    private fun setupEventListeners() {
        iniciar.setOnClickListener {
            val correo = correo.text.toString()
            val contrasena = contrasena.text.toString()
            if (correo.isEmpty() || contrasena.isEmpty()) {
                lblError.text = "Todos los campos son obligatorios"
                lblError.visibility = TextView.VISIBLE
                return@setOnClickListener
            }
            val usuario = UsuarioRepository.getAllUsuarios(this)
            for (i in usuario) {
                if (i.correo == correo && i.contrasena == contrasena) {
                    val bundle = Bundle()
                    bundle.putString("usuario", i.nombre)
                    bundle.putInt("usuarioId", i.id)
                    val intent = Intent(this, RestaurantesActivity::class.java)
                    intent.putExtras(bundle)
                    startActivity(intent)
                } else {
                    lblError.text = "Usuario o contraseña incorrectos"
                    lblError.visibility = TextView.VISIBLE
                }
            }
        }
        crear.setOnClickListener {
            val intent = Intent(this, FormUsuario::class.java)
            startActivity(intent)
        }
    }

}