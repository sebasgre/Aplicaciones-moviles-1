package com.moviles.burguerweek.dal.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Usuarios(
    val nombre: String,
    val apellido: String,
    val correo: String,
    val contrasena: String,
    var IsEaten: Boolean
) {
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0
}

