package com.moviles.burguerweek.dal.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.moviles.burguerweek.dal.entities.Restaurantes

@Dao
interface RestaurantesDao {
    @Query("SELECT * FROM restaurantes")
    fun getAll(): List<Restaurantes>

    @Query("SELECT * FROM restaurantes WHERE id = :id")
    fun getById(id: Int): Restaurantes?

    @Insert
    fun insert(restaurante: Restaurantes)
}