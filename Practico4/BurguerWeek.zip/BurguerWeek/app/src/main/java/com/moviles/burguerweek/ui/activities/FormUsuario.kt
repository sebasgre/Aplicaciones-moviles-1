package com.moviles.burguerweek.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.moviles.burguerweek.R
import com.moviles.burguerweek.dal.entities.Usuarios
import com.moviles.burguerweek.repository.UsuarioRepository

class FormUsuario : AppCompatActivity() {
    private lateinit var nombre: EditText
    private lateinit var apellido: EditText
    private lateinit var correo: EditText
    private lateinit var contrasena: EditText
    private lateinit var crear: Button
    private lateinit var lblError: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_usuario)
        nombre = findViewById(R.id.txtNombre)
        apellido = findViewById(R.id.txtApellido)
        correo = findViewById(R.id.correo2)
        contrasena = findViewById(R.id.contraseña2)
        crear = findViewById(R.id.btnCrear2)
        lblError = findViewById(R.id.lblError2)
        setupEventListeners()
    }

    private fun setupEventListeners() {
        crear.setOnClickListener {
            val nombre = nombre.text.toString()
            val apellido = apellido.text.toString()
            val correo = correo.text.toString()
            val contrasena = contrasena.text.toString()
            if (nombre.isEmpty() || apellido.isEmpty() || correo.isEmpty() || contrasena.isEmpty()) {
                lblError.text = "Todos los campos son obligatorios"
                lblError.visibility = TextView.VISIBLE
                return@setOnClickListener
            } else {
                val usuario = Usuarios(nombre, apellido, correo, contrasena, false)
                UsuarioRepository.insert(usuario, this)
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
        }
    }
}