package com.moviles.burguerweek.dal.entities

import android.content.Context
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.CASCADE
import androidx.room.PrimaryKey
import com.moviles.burguerweek.repository.RestauranteRepository

@Entity(
    foreignKeys = [ForeignKey(
        entity = Restaurantes::class,
        parentColumns = arrayOf("id"),
        childColumns = arrayOf("idRestaurante"),
        onDelete = CASCADE
    )]
)

data class Hamburguesas(
    val nombre: String,
    val descripcion: String,
    val foto: String,
    val idRestaurante: Int
) {

    fun getRestaurante(context: Context): Restaurantes? {
        return RestauranteRepository.getRestauranteById(idRestaurante, context)
    }

    @PrimaryKey(autoGenerate = true)
    var id: Int = 0
}
