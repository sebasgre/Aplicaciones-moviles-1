package com.moviles.burguerweek.dal.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.moviles.burguerweek.dal.entities.Reviews

@Dao
interface ReviewDao {
    @Query("SELECT * FROM reviews")
    fun getAll(): List<Reviews>

    @Query("SELECT * FROM reviews WHERE id = :id")
    fun getById(id: Int): Reviews?

    @Query("SELECT * FROM reviews WHERE idHamburguesa = :id")
    fun getReviewsByHamburguesa(id: Int): List<Reviews>

    @Insert
    fun insert(review: Reviews)

    @Update
    fun update(review: Reviews)

    @Delete
    fun delete(review: Reviews)
}