package com.moviles.burguerweek.repository

import android.content.Context
import com.moviles.burguerweek.dal.db.AppDataBase
import com.moviles.burguerweek.dal.entities.Hamburguesas

object HamburguesaRepository {
    fun getAllHamburguesas(context: Context): List<Hamburguesas> {
        val hamburguesaDao = AppDataBase.getDatabase(context).hamburguesaDao()
        return hamburguesaDao.getAll()
    }

    fun getHamburguesaById(id: Int, context: Context): Hamburguesas? {
        val hamburguesaDao = AppDataBase.getDatabase(context).hamburguesaDao()
        return hamburguesaDao.getById(id)
    }

    fun getHamburguesaByRestaurante(id: Int, context: Context): List<Hamburguesas>? {
        val hamburguesaDao = AppDataBase.getDatabase(context).hamburguesaDao()
        return hamburguesaDao.getByRestaurante(id)
    }

    fun insert(hamburguesa: Hamburguesas, context: Context) {
        val hamburguesaDao = AppDataBase.getDatabase(context).hamburguesaDao()
        hamburguesaDao.insert(hamburguesa)
    }

}