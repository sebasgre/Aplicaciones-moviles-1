package com.moviles.burguerweek.repository

import android.content.Context
import com.moviles.burguerweek.dal.db.AppDataBase
import com.moviles.burguerweek.dal.entities.Usuarios

object UsuarioRepository {
    fun getAllUsuarios(context: Context): List<Usuarios> {
        val usuarioDao = AppDataBase.getDatabase(context).usuarioDao()
        return usuarioDao.getAll()
    }

    fun getUsuarioById(id: Int, context: Context): Usuarios? {
        val usuarioDao = AppDataBase.getDatabase(context).usuarioDao()
        return usuarioDao.getById(id)
    }

    fun insert(usuario: Usuarios, context: Context) {
        val usuarioDao = AppDataBase.getDatabase(context).usuarioDao()
        usuarioDao.insert(usuario)
    }

}