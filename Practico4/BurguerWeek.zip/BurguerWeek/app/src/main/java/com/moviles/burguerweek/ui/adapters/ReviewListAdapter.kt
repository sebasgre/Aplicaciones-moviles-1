package com.moviles.burguerweek.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.moviles.burguerweek.R
import com.moviles.burguerweek.dal.entities.Reviews
import com.moviles.burguerweek.repository.UsuarioRepository

class ReviewListAdapter(val data: ArrayList<Reviews>, val listener: onReviewListener) :
    RecyclerView.Adapter<ReviewListAdapter.ReviewViewHolder>() {
    class ReviewViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val lblUsuarioNombre: TextView = itemView.findViewById(R.id.lblNombreUsuario)
        val txtCalificacion: RatingBar = itemView.findViewById(R.id.ratingBar2)
        val txtdescripcion: TextView = itemView.findViewById(R.id.txtDescripcion2)
        val btnEdit: Button = itemView.findViewById(R.id.btnEdit)
        val btnDelete: Button = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReviewViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.review_item_layout, parent, false)
        return ReviewViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReviewViewHolder, position: Int) {
        val review = data[position]
        val usuario = UsuarioRepository.getUsuarioById(review.idUsuario, holder.itemView.context)
        holder.lblUsuarioNombre.text = usuario!!.nombre
        holder.txtCalificacion.rating = review.calificacion.toFloat()
        holder.txtdescripcion.text = review.comentario
        holder.btnEdit.setOnClickListener {
            listener.onReviewEdit(review)
        }
        holder.btnDelete.setOnClickListener {
            listener.onReviewDelete(review)
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }

    fun refreshData(reviews: List<Reviews>) {
        data.clear()
        data.addAll(reviews)
        notifyDataSetChanged()
    }

    interface onReviewListener {
        fun onReviewEdit(review: Reviews)
        fun onReviewDelete(review: Reviews)
    }
}
