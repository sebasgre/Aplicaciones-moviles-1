package com.moviles.burguerweek.dal.entities

import android.content.Context
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.CASCADE
import androidx.room.PrimaryKey
import com.moviles.burguerweek.repository.HamburguesaRepository
import com.moviles.burguerweek.repository.UsuarioRepository


@Entity(
    foreignKeys = [ForeignKey(
        entity = Hamburguesas::class,
        parentColumns = arrayOf("id"),
        childColumns = arrayOf("idUsuario"),
        onDelete = CASCADE
    ), ForeignKey(
        entity = Hamburguesas::class,
        parentColumns = arrayOf("id"),
        childColumns = arrayOf("idHamburguesa"),
        onDelete = CASCADE
    )]
)

data class Reviews(
    val idUsuario: Int,
    val idHamburguesa: Int,
    val calificacion: Float,
    val comentario: String
) {

    fun getUsuario(context: Context): Usuarios? {
        return UsuarioRepository.getUsuarioById(idUsuario, context)
    }

    fun getHamburguesa(context: Context): Hamburguesas? {
        return HamburguesaRepository.getHamburguesaById(idHamburguesa, context)
    }

    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

}