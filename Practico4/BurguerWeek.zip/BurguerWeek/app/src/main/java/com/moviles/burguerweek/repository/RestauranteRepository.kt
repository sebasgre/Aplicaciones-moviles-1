package com.moviles.burguerweek.repository

import android.content.Context
import com.moviles.burguerweek.dal.db.AppDataBase
import com.moviles.burguerweek.dal.entities.Restaurantes

object RestauranteRepository {

    fun getAllRestaurantes (context: Context): List<Restaurantes> {
        val restauranteDao = AppDataBase.getDatabase(context).restaurantesDao()
        return restauranteDao.getAll()
    }

    fun getRestauranteById(id: Int, context: Context): Restaurantes? {
        val restauranteDao = AppDataBase.getDatabase(context).restaurantesDao()
        return restauranteDao.getById(id)
    }

    fun insert(restaurante: Restaurantes, context: Context) {
        val restauranteDao = AppDataBase.getDatabase(context).restaurantesDao()
        restauranteDao.insert(restaurante)
    }
}